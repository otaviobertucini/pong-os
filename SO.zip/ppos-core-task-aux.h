#define IS_CONTAB 1

void bodyDispatcher();

void handler_tick(int signum);